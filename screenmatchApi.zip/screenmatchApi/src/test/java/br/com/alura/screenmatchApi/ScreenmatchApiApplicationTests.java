package br.com.alura.screenmatchApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScreenmatchApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
